# How to publish this repo (for Mike)

These are the steps to put this folder on GitHub and turn on the web page.
Claude prepared the files; you create the repo and push. Nothing here has been
sent or published.

## 1. Create the repository
- Go to github.com → New repository.
- Name: **web-browsers-pervasive-accessibility**
- Visibility: **Public**
- Do NOT initialize with a README (this folder already has one).

## 2. Add these files
Easiest (no command line): on the new empty repo page, click
**"uploading an existing file"** and drag in everything from this folder:
- index.html
- README.md
- LICENSE
- .nojekyll
- web-browsers-as-a-pervasive-accessibility-solution.pdf
- web-browsers-as-a-pervasive-accessibility-solution.docx
Then click **Commit changes**.

(Or, from a terminal in this folder:)
```
git init
git add .
git commit -m "Add Web Browsers as a Pervasive Accessibility Solution (review draft v1.5)"
git branch -M main
git remote add origin https://github.com/mikepaciello/web-browsers-pervasive-accessibility.git
git push -u origin main
```

## 3. Turn on GitHub Pages (the readable web version)
- In the repo: **Settings → Pages**.
- Under "Build and deployment", Source = **Deploy from a branch**.
- Branch = **main**, folder = **/ (root)**. Save.
- After a minute, the page is live at:
  **https://mikepaciello.github.io/web-browsers-pervasive-accessibility/**
- The README's "Read online" link and the HTML already point to that URL.

## 4. (Later) Add the Zenodo DOI
- Deposit the PDF on Zenodo, pick your license, get the DOI.
- Paste the DOI into the README's "How to cite" section (and the paper) where
  the placeholder notes it.

## Notes
- If your GitHub username is not "mikepaciello", tell Claude and the one URL in
  the README + HTML will be corrected.
- To update the paper later: replace the PDF/DOCX/index.html and commit again.
